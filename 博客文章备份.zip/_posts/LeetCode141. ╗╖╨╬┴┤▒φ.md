---
title: LeetCode面试题 02.07.链表相交
date: 2022-01-02 20:24:59
tags: 
	- 数据结构与算法
	- LeetCode
---


#### [面试题 02.07. 链表相交](https://leetcode-cn.com/problems/intersection-of-two-linked-lists-lcci/)<!--more-->



> 给你一个链表的头节点 `head` ，判断链表中是否有环。
>
> 如果链表中有某个节点，可以通过连续跟踪 next 指针再次到达，则链表中存在环。 为了表示给定链表中的环，评测系统内部使用整数 `pos `来表示链表尾连接到链表中的位置（索引从 0 开始）。注意：`pos` 不作为参数进行传递 。仅仅是为了标识链表的实际情况。
>
> 如果链表中存在环 ，则返回 `rue` 。 否则，返回 `false` 。
>
>  
>
> 示例 1：
> 
> 	输入：head = [3,2,0,-4], pos = 1
>	输出：true
> 	解释：链表中有一个环，其尾部连接到第二个节点。
>
> 示例 2：
> 
>	输入：head = [1,2], pos = 0
> 	输出：true
>	解释：链表中有一个环，其尾部连接到第一个节点。
> 
> 示例 3：
>
> 	输入：head = [1], pos = -1
>	输出：false
> 	解释：链表中没有环。
> 
>
>提示：
> 
>	链表中节点的数目范围是 [0, 104]
> 	-105 <= Node.val <= 105
> 	pos 为 -1 或者链表中的一个`有效索引`。
> 

---

## 此题采用双指针法

​	快慢指针法，快指针每次移动两个节点，慢指针每次移动一个节点，有环的话，一定会在环内相遇。

​	注意若链表无环，快指针一定先到达链表尾部，且快指针`fast->next->next`有可能产生空指针异常，故循环条件为`fast != NULL && fast->next != NULL`

```c++
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    bool hasCycle(ListNode *head) {
        if (head == NULL || head->next == NULL) {
            return false;
        }
        ListNode *fast = head, *slow = head;
        
        // fast一定在slow前面，因此循环条件为fast不为null并且fast->next不为null
        while(fast != NULL && fast->next != NULL) {
            slow = slow->next;
            fast = fast->next->next;
            if (fast == slow) {
                return true;
            }
        }
        return false;
    }
};
```