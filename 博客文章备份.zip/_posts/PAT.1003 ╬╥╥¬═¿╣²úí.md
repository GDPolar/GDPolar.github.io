---
title: 1003 我要通过！
date: 2022-03-31 20:24:59
tags: 
	- 数据结构与算法
	- PAT
---


#### [1003 我要通过！](https://pintia.cn/problem-sets/994805260223102976/problems/994805323154440192)<!--more-->



> 只要读入的字符串满足下列条件，系统就输出”答案正确“，否则输出“答案错误”。
>
> 得到”答案正确“的条件是：
>
> 1. 字符串中必须仅有 `P`、 `A`、 `T`这三种字符，不可以包含其它字符；
> 2. 任意形如 `xPATx` 的字符串都可以获得”答案正确“，其中 `x` 或者是空字符串，或者是仅由字母 `A` 组成的字符串；
> 3. 如果 `aPbTc` 是正确的，那么 `aPbATca` 也是正确的，其中 `a`、 `b`、 `c` 均或者是空字符串，或者是仅由字母 `A` 组成的字符串。
>
> 现在就请你为 PAT 写一个自动裁判程序，判定哪些字符串是可以获得”答案正确“的。
>
> ## 输入格式：
>
> 每个测试输入包含 1 个测试用例。第 1 行给出一个正整数 n (≤10)，是需要检测的字符串个数。接下来每个字符串占一行，字符串长度不超过 100，且不包含空格。
>
> ## 输出格式：
>
> 每个字符串的检测结果占一行，如果该字符串可以获得“*答案正确**，则输出 `YES`，否则输出 `NO`。
>
> ## 输入样例：
>
> 	10
> 	PAT
> 	PAAT
> 	AAPATAA
> 	AAPAATAAAA
> 	xPATx
> 	PT
> 	Whatever
> 	APAAATAA
> 	APT
> 	APATTAA
>
> ## 输出样例：
>
> 	YES
> 	YES
> 	YES
> 	YES
> 	NO
> 	NO
> 	NO
> 	NO
> 	NO
> 	NO
> 


---

## 此题目主要难度在理解题意

由规则1知：必须要有PAT三个字符，P,T有且只有一个，P在T前面。

由规则2和规则3可知：以P和T为边界可以分为三部分：++++++P+++++++T++++++，也就是画加号的三部分。若加号都是由字母A组成，则以上归纳出来的规律如下的：

如果P之前的A的个数为n1，P到T之间的A个数为n2,T之后的A的个数为n3，那么有n3=n2*n1.

```java
import java.util.Scanner;

public class Main{

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        while (scanner.hasNext()){
            String string = scanner.next();
            if (judge(string)) {
                System.out.println("YES");
            }
            else {
                System.out.println("NO");
            }
        }
    }

    /*
     * 只能有一个P和一个T，且P和T的位置顺序不可颠倒
     * 在P和T间至少有一个A，即zhong至少应该为1
     * zuo * zhong == you
     * 即字符串为：zuo个A字母+P+zhong个A字母+一个A字母+T+you个A字母
    */
    private static boolean judge(String n) {
        int zuo = 0, you = 0, zhong = 0;
        // pN、tN只能取0、1
        int pN = 0, tN = 0;
        // passP和passT来判断相对位置：左、中、右
        boolean passP = false, passT = false;
        // 正则表达式"^[PAT]+$"确保字符串只有P、A、T三种字母
        if (n.matches("^[PAT]+$")){
            for (int i = 0; i < n.length(); i++) {
                int t = n.charAt(i);
                if (t == 'P') {
                    passP = true;
                    pN++;
                }
                else if (t == 'T') {
                    passT = true;
                    tN++;
                }
                else {
                    if (!passP && !passT){
                        zuo++;
                    }
                    else if (passP && !passT){
                        zhong++;
                    }
                    else
                        you++;
                }
            }
            if (zhong == 0 || pN != 1 || tN != 1) return false;
            if (zuo * zhong == you) return true;
        }
        return false;
    }
}
```