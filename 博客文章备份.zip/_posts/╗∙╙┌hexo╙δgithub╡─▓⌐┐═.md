---
title: 基于hexo与github的博客
date: 2019-01-01 20:24:59
tags: 博客
---

[toc]



## 利用hexo框架搭建个人博客并部署到GitHub page中

<!--more-->

## 1、设置npm源为淘宝源

```
npm install -g cnpm --registry=https://registry.npm.taobao.org
```

## 2、利用npm安装hexo客户端

```
cnpm install -g hexo-cli
```

## 3、初始化hexo创建默认的博客文件

```
hexo init
```

![image-20211230225907031](https://s2.loli.net/2021/12/31/izu5TtMZOcVo9pl.png)

## 4、初始化git

```
git init
git config --global user.email "2249303992@qq.com"
git config --global user.name "GDPlar"
```

![image-20211230230155589](https://s2.loli.net/2021/12/31/lSwXzF5T61Qkjb9.png)

![image-20211230230328410](https://s2.loli.net/2021/12/31/RnqbxjmrYfQsXI8.png)

## 5、部署前的工作

修改_config.yml中的如下字段，注意冒号后有一个空格

```
# Deployment
## Docs: https://hexo.io/docs/one-command-deployment
deploy:
  type: 'git'
  repo: https://github.com/GDPolar/GDPolar.github.io.git
  branch: master
```

生成一个Github的token

在Github中点击Settings->Developer settings->Personal access tokens->Generate new token 以创建一个token

注意关闭页面后就再也看不到token，因此需及时复制

在blog目录下安装git部署插件

```
cnpm install --save hexo-deployer-git
```



## 6、部署到到Github上

```
hexo d
```

![image-20211230231049007](https://s2.loli.net/2021/12/31/yQmtRpHkDvaueVW.png)

## 7、博客位于/source\_posts文件夹中

## 8、在仓库里添加CNAME文件并在文件中填写绑定的域名

仓库的Settings中找到 Custom domain添加域名后保存![image-20220104221635850](https://s2.loli.net/2022/01/04/LFyIDqsuKlaUzcR.png)

在\Blog\source路径下创建名为CNAME的文件，文件内容为gdpolar.top

![image-20220104221018960](https://s2.loli.net/2022/01/04/wbqHpf3uNKkTzQh.png)

## 9、添加域名解析

ping gdpolar.github.io，得到IP

在腾讯云的DNSPod添加如下两条记录即可

![image-20220104220643160](https://s2.loli.net/2022/01/04/zwiH95DdBnrOeYc.png)

