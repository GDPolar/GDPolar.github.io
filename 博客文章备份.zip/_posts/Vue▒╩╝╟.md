---
title: Vue2笔记1
date: 2022-03-10 20:24:59
tags: Vue
---

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../vue.js"></script>
    <title>Demo1</title>
</head>
<body>
    <div id="root">
        <!-- 插值语法，使用两个大括号 -->
        <!-- {{XXX}}中的XXX要写JS表达式，且XXX可以自动读取到data中的所有属性 -->
        <h1>hello:{{name.toUpperCase()}} !</h1> 

        <!-- 指令语法，用于解析标签（标签属性、标签体内容、绑定事件...） -->
        <h4>
            <!-- 属性前加上 v-bind: 属性绑定 -->
            <input v-bind:value="url"><br>
            <!-- v-bind: 可简写为 : -->
            单项数据绑定:<input :value="url"><br>

            <!-- v-model 双向绑定 -->
            <!-- 只可用于表单类元素（input、select等），v-model:value可简写为v-model -->
            <input v-model:value="url"><br>
            双向数据绑定:<input v-model="url"><br>
        </h4>
    </div>

    <script>
        Vue.config.productionTip = false;
        // Vue实例与容器是一对一的关系
        new Vue({
            el : "#root",    // el属性用于指定当前Vue实例所服务的容器，通常为CSS选择器字符串
            data : {        // data属性的值可为对象，在容器中用两个大括号引用
                name : "zhangsan",
                url : "http://gdpolar.top"
            }
        });
    </script>
</body>
</html>
```

