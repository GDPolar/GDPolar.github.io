---
title: C++ STL
date: 2020-06-13 14:21:42
tags: 
	- 数据结构与算法
	- 刷题总结
---

[toc]
<!--more-->

## 头文件

```c++
#include <ciostream>
#include <string> // string中可以进行+ = += >等运算
#include <cctype> // 字符测试，判断字符是否是数字、字母，tolower() 和toupper() 如果参数是大(小)写字符，返回其小(大)写，否则返回该参数
```

## cout输出控制

```c++
#include <iostream> 
#include <string>
using namespace std;
int main() {
    bool t = true;
    // bool类型数据输出时要加 boolalpha
    cout << t << endl; // 1
    cout << boolalpha << t << endl; // true
    return 0;
}

```

## C++定义二维数组
```c++
vector<vector<int>> res(n, vector<int>(n, 0)); // 定义n*n的二维数组
```

## 字符串 <string>

```c++
// 引入iostream 和 string 这两个头文件
#include <iostream> 
#include <string>
using namespace std;
int main() {
    
    // string可以用加号拼接
    string s1 = "hello", s2 = " world";
    cout << s1 + s2 << endl;
    
    // 读入字符串
    string s, t;
    cin >> s;  // 读取s，不包括空格
    getline(cin, t); // 读取⼀整⾏的字符串，包括空格
        
    // 字符串长度length()
    int length = s.length();
    // int length = s.size();  
    // string类的size()与length()没有任何区别
    
    // 字符串模式匹配find()
    s = "aaabbb", t1 = "abb", t2 = "c";
    s.find(t1); // 返回首次匹配位置2
    s.find(t2); // 返回string:npos，其中string:npos是个特殊值，说明查找没有匹配
    
    
    // 反转字符串reverse(s.begin(), s.end())
    s = "hello world";
    reverse(s.begin(), s.end());
    cout << s << endl; // dlrow olleh
	
    // 构造子串s.substr(pos, n)，返回一个从第pos位开始的长度为n的子串
    s = "hello world";
    cout << s.substr(2, 3) << endl; // llo
    
    return 0;
}

```

## 栈 <stack>

```c++
// 引入iostream 和 stack 这两个头文件
#include <iostream>
#include <stack>
using namespace std;
int main() {
    /*
        stack<int> s;
        s.empty()               如果栈为空返回true，否则返回false
        s.size()                返回栈中元素的个数
        s.pop()                 删除栈顶元素但不返回其值
        s.top()                 返回栈顶的元素，但不删除该元素
        s.push()                在栈顶压入新元素
	 */
    
    // stack<DataType> 初始化一个栈
    stack<int> s; 
    cout << boolalpha << s.empty() << endl; // true
    s.push(8);
    cout << s.top() << endl; // 8
    cout << s.size() << endl;  // 1
    s.pop(); 
    return 0;
}

```

## 队列<queue>

```c++
// 引入iostream 和 queue 这两个头文件
#include <iostream>
#include <queue>
int main() {
    /*
		queue<int> q;
        q.empty()               如果队列为空返回true，否则返回false
        q.size()                返回队列中元素的个数
        q.pop()                 删除队列首元素但不返回其值
        q.front()               返回队首元素的值，但不删除该元素
        q.push()                在队尾压入新元素
        q.back()                返回队列尾元素的值，但不删除该元素
    */
    return 0;
}
```

## 集合<set>

​	set中各元素各不相同，且set内升序排序

​	unordered_set 即是官方的hash_set

|        集合        | 底层实现 | 是否有序 | 数值是否可重复 | 能否更改数值 | 查询效率 | 增删效率 |
| :----------------: | :------: | :------: | :------------: | :----------: | :------: | :------: |
|      std::set      |  红黑树  |   有序   |       否       |      否      | O(log n) | O(log n) |
|   std::multiset    |  红黑树  |   有序   |       是       |      否      | O(log n) | O(log n) |
| std::unordered_set |  哈希表  |   无序   |       否       |      否      |   O(1)   |   O(1)   |

```c++
// 引入iostream 和 set 这两个头文件
// std::unordered_set 底层实现为哈希表，无序
#include <iostream>
#include <set>
using namespace std;
int main() {
     /*
        set<int> s;
        s.insert()              向集合添加一个元素
		s.erase()               删除一个元素
		s.count()               判断元素是否在set中
		s.size()                获取元素个数
		s.clear()               清空
	 */
    
    set<int> s;
    s.insert(2);
    s.insert(3);
    cout << *(s.begin()) << endl; //输出第一个元素
    for (int i = 0; i < 10; i++) {//插入0 - 9
        s.insert(i);
    }
    for (set<int>::iterator it = s.begin(); it != s.end(); it++) {
        cout << *it << " ";//集合的遍历，it是一个迭代的指针
    }
    cout << endl << (s.find(2) != s.end()) << endl;//查找，元素
    s.erase(3);//删除元素
    cout << (s.find(3) != s.end()) << endl;
    return 0;
}

```

## map<map>

|        映射        | 底层实现 | 是否有序 | 数值是否可以重复 | 能否更改数值 | 查询效率 | 增删效率 |
| :----------------: | :------: | :------: | :--------------: | :----------: | :------: | :------: |
|      std::map      |  红黑树  | key有序  |   key不可重复    | key不可修改  | O(log n) | O(log n) |
|   std::multimap    |  红黑树  | key有序  |    key可重复     | key不可修改  | O(log n) | O(log n) |
| std::unordered_map |  哈希表  | key无序  |   key不可重复    | key不可修改  |   O(1)   |   O(1)   |

​	unordered_map 即是官方的hash_map

```c++
// 引入iostream 和 unordered_map 这两个头文件
#include <iostream>
#include <unordered_map>
#include <string>
using namespace std;
int main() {
	/*
		unordered_map<string, string> um;
        um.find()				查找以 key 为键的键值对
		um.emplace()            向容器中添加新键值对
		um.erase()              删除指定键值对
		um.size()               获取元素个数
		um.clear()              清空
	 */
    
    
    map<string, string> m;
    m["hello"] = "world"; // 存储键为 "hello" 值为 "world"的键值对
    cout << m["hello"] << endl; // 访问map中key为"hello"的value,
    cout << m["world"] << endl;// 如果key不存在，则返回0或空
    m["world"] = "test"; // 将"world"键对应的值修改为3
    m["key"] = "value"; // 设置键为 "key" 值为"value" 的键值对
    //迭代器遍历，输出map中所有的元素，键it->first获取，值it->second获取
    for (map<string, string>::iterator it = m.begin(); it != m.end(); it++) {
        cout << it->first << " " << it->second << endl;
    }

    cout << m.begin()->first << " " << m.begin()->second << endl;
    // 访问map的第一个元素，输出它的键和值

    cout << m.rbegin()->first << " " << m.rbegin()->second << endl;
    // 访问map的最后一个元素，输出它的键和值

    cout << m.size() << endl;
    // 输出map的元素个数
    return 0;
}

```

## 向量<vector>

​	vector是一个能够存放任意类型的动态数组，能增加和压缩数据

```c++
vector<int>test; // 定义的时候不指定vector的⼤⼩
vector<int>test2(6); // 定义的时候指定vector的⼤⼩，默认test2⾥⾯元素都是0
vector<int>test3(6, 3); // 定义的时候指定vector的⼤⼩，默认test3⾥⾯元素都是3
// 相当于构造函数第一个参数为大小，第二个参数为内容
vector<vector<int>> res(n, vector<int>(n, 0)); // 定义n*n的二维数组

//尾部添加两个元素，0的位置存储5， 1 的位置存储8
test.push_back(5);
test.push_back(8);

test.insert(test.begin()+i,value);//在第i+1个元素前面插入value;
test.erase(test.begin() + 5);//删除第6个元素
test.clear();//clear，清空向量
test.size();// 获取长度
test.begin();//起始地址
test.end();//结束地址

//遍历向量
for (vector<int>test::iterator it = m.begin(); it != m.end(); it++) {
        cout << *it << endl;
}

reverse(test.begin(),test.end());//反转

sort(test.begin(), test.end());
//自定义排序规则，“小于”
bool comp(const student &a, const student &b){
	return a.score < b.score;
}
sort(test.begin(), test.end(), comp);
```

