---
title: LeetCode面试题 02.07.链表相交
date: 2022-01-02 20:24:59
tags: 
	- 数据结构与算法
	- LeetCode
---


#### [面试题 02.07. 链表相交](https://leetcode-cn.com/problems/intersection-of-two-linked-lists-lcci/)<!--more-->



> 给你两个单链表的头节点 headA 和 headB ，请你找出并返回两个单链表相交的起始节点。如果两个链表没有交点，返回 null 。
>
> 示例 1：
>
> 	输入：listA = [4,1,8,4,5], listB = [5,0,1,8,4,5]
> 	输出：Intersected at '8'
>
> 示例 2：
>
> 	输入：listA = [0,9,1,2,4], listB = [3,2,4]
> 	输出：Intersected at '2'
>
> 示例 3：
>
> 	输入：listA = [2,6,4], listB = [1,5]
> 	输出：null
>
>
> 提示：
>
> 	listA 中节点数目为 m
> 	listB 中节点数目为 n
> 	0 <= m, n <= 3 * 104
> 	1 <= Node.val <= 105
> 	0 <= skipA <= m
> 	0 <= skipB <= n
> 	如果 listA 和 listB 没有交点，intersectVal 为 0
> 	如果 listA 和 listB 有交点，intersectVal == listA[skipA + 1] == listB[skipB + 1]

---

## 此题采用双指针法

​	添加虚拟头结点方便处理

​	让快指针先移动n步，然后让两指针同时移动，直到快指针指向链表末尾时，删掉慢指针所指向的节点即可

```c++
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    ListNode *getIntersectionNode(ListNode *headA, ListNode *headB) {
        if (headA == NULL || headB == NULL) {
            return NULL;
        }
        int lengthA = 0, lengthB = 0;
        ListNode *t, *tA = headA, *tB = headB;
        t = headA;
        while (t != NULL) {
            lengthA++;
            t = t->next;
        }
        t = headB;
        while (t != NULL) {
            lengthB++;
            t = t->next;
        }
        if (lengthA < lengthB) {
            for (int i = lengthB - lengthA; i > 0; i--) {
                tB = tB->next;
            }
        }
        else {
            for (int i = lengthA - lengthB; i > 0; i--) {
                tA = tA->next;
            }
        }
        while (tA != tB && tA != NULL) {
            tA = tA->next;
            tB = tB->next;
        }
        return tA;
    }
};
```