---
title: LeetCode206. 反转链表
date: 2022-01-01 20:24:59
tags: 
	- 数据结构与算法
	- LeetCode
---


#### [206. 反转链表](https://leetcode-cn.com/problems/reverse-linked-list/)<!--more-->



> 给你单链表的头节点 head ，请你反转链表，并返回反转后的链表。
>
> 示例 1：
>
> 	输入：head = [1,2,3,4,5]
>	输出：[5,4,3,2,1]
> 
> 示例 2：
> 
>	输入：head = [1,2]
> 	输出：[2,1]
>
> 示例 3：
> 
>	输入：head = []
> 	输出：[]
>
> 
> 提示：
>
> 	链表中节点的数目范围是 [0, 5000]
> 	-5000 <= Node.val <= 5000

---

## 递归法

假设链表为

​	n<sub>1</sub> --> ..... --> n<sub>k-1</sub> -- >  n<sub>k</sub> -->  n<sub>k+1</sub> --> ... --> n<sub>m</sub> --> ∅

若从节点 n<sub>k+1</sub> 到 n<sub>m</sub> 已经被反转，此时正处于 n<sub>k</sub> 

​	n<sub>1</sub> --> ..... --> n<sub>k-1</sub> -- >  n<sub>k</sub> -->  n<sub>k+1</sub> <-- ... <-- n<sub>m</sub> <-- ∅

所以令n<sub>k</sub>->next->next = n<sub>k</sub>;

理解递归的关键在于不要在乎递归内部，把递归函数当作一个普通函数且只关心其输入输出，即把递归当作**黑盒函数**

```c++
class Solution {
public:
    ListNode* reverseList(ListNode* head) {
        // 由于要执行 head->next->next = head，所以 head->next 不能为空
        if (head == nullptr || head->next == nullptr) {
            return head;
        }
        ListNode* newHead = reverseList(head->next); 
        head->next->next = head;
        head->next = nullptr;
        return newHead;
    }
};

```

---

## 双指针法

通过两个前后指针顺序遍历链表并反转

由于此题链表无头节点，则p、q指针初始值分别为p = nullptr, q = head

若为有头节点链表，则p、q指针初始值分别为p = head, q = head->next

```c++
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public:
    ListNode* reverseList(ListNode* head) {
        ListNode* p = nullptr, *q = head, *t;
        while (q != nullptr) {
            t = q->next; // 临时保存快指针的下一节点
            q->next = p;
            p = q;
            q = t;
        }
        return p;
    }
};
```



