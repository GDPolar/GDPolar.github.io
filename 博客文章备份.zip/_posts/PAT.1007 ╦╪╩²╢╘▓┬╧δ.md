---
title: 1007 素数对猜想
date: 2022-03-31 20:24:59
tags: 
	- 数据结构与算法
	- PAT
---


#### [1007 素数对猜想](https://pintia.cn/problem-sets/994805260223102976/problems/994805317546655744)<!--more-->



> 让我们定义d<sub>n</sub>为：d<sub>n</sub>=p<sub>n+1</sub>−p<sub>n</sub>，其中p<sub>i</sub>是第i个素数。显然有d<sub>1</sub>=1，且对于n>1有d<sub>n</sub>是偶数。“素数对猜想”认为“存在无穷多对相邻且差为2的素数”。
>
> 现给定任意正整数`N`(<10^5)，请计算不超过`N`的满足猜想的素数对的个数。
>
> ## 输入格式：
>
> 输入在一行给出正整数`N`。
>
> ## 输出格式：
>
> 在一行中输出不超过`N`的满足猜想的素数对的个数。
>
> ## 输入样例1：
>
> 	20
> 
>
>
> ## 输出样例1：
>
> 	4
> 
>


---



```c++
#include <iostream>
#define endl '\n'

using namespace std;

// 判断素数
bool isPrime(int n) {
	if (n == 1 || n == 2) {
		return true;
	}
    // 只需判断到不大于n^(1/2)
	for (int i = 2; i * i <= n; i++) {
		if (n % i == 0)	{
			return false;
		}
	}
	return true;
}

int main() {
	int count = 0;
	int n;
	scanf("%d", &n);
    // 素数：1, 2, 3, 5, 7.... 
	for (int i = 5; i <= n; i++) {
		if (isPrime(i-2) && isPrime(i)) {
			count++;
		}
	}
	printf("%d\n", count);
	return 0;
}


```

