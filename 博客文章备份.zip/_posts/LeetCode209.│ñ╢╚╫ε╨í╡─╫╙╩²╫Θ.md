---
title: LeetCode209.长度最小的子数组
date: 2022-01-01 20:24:59
tags: 
	- 数据结构与算法
	- LeetCode
---


#### [209. 长度最小的子数组](https://leetcode-cn.com/problems/minimum-size-subarray-sum/)<!--more-->



> 给定一个含有 n 个正整数的数组和一个正整数 target 。
>
> 找出该数组中满足其和 ≥ target 的长度最小的 连续子数组 [numsl, numsl+1, ..., numsr-1, numsr] ，并返回其长度。如果不存在符合条件的子数组，返回 	0 。
>
> 示例 1：
>
> 	输入：target = 7, nums = [2,3,1,2,4,3]
> 	输出：2
> 	解释：子数组 [4,3] 是该条件下的长度最小的子数组。
>
> 示例 2：
>
> 	输入：target = 4, nums = [1,4,4]
> 	输出：1
>
> 示例 3：
>
> 	输入：target = 11, nums = [1,1,1,1,1,1,1,1]
> 	输出：0
>
> 
> 提示：
>
>	1 <= target <= 109
>	1 <= nums.length <= 105
>	1 <= nums[i] <= 105

---

## 此题可采用“滑动窗口法”

​	所谓滑动窗口，就是不断的调节子序列的起始位置和终止位置，从而得出要想的结果。

​	窗口的起始位置如何移动：如果当前窗口的值大于s了，窗口就要向前移动了（也就是该缩小了）。

​	窗口的结束位置如何移动：窗口的结束位置就是遍历数组的指针，窗口的起始位置设置为数组的起始位置就可以了。

```c++
class Solution {
public:
    int minSubArrayLen(int target, vector<int>& nums) {
        if (nums.size() == 0) return 0;
        int res = 999999, sum = nums[0];
        int i = 0, j = 0; 
        while (i <= j && j < nums.size()) {
            if (sum < target) { // 结束位置右滑
                if (++j < nums.size())  // 防止数组超过最右边界
                    sum += nums[j];
            } else {
                if( res > (j - i + 1) ) // 起始位置右滑
                    res = j - i + 1;
                sum -= nums[i++];
            }
        }
        if (res == 999999) return 0;
        return res;
    }
};
```