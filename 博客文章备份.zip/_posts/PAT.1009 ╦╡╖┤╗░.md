---
title: 1009 说反话
date: 2022-03-31 20:24:59
tags: 
	- 数据结构与算法
	- PAT
---


#### [1009 说反话](https://pintia.cn/problem-sets/994805260223102976/problems/994805314941992960)<!--more-->



> 给定一句英语，要求你编写程序，将句中所有单词的顺序颠倒输出。
>
> ## 输入格式：
>
> 测试输入包含一个测试用例，在一行内给出总长度不超过 80 的字符串。字符串由若干单词和若干空格组成，其中单词是由英文字母（大小写有区分）组成的字符串，单词之间用 1 个空格分开，输入保证句子末尾没有多余的空格。
>
> ## 输出格式：
>
> 每个测试用例的输出占一行，输出倒序后的句子。
>
> ## 输入样例1：
>
> 	Hello World Here I Come
> 
>
>
> ## 输出样例1：
>
> 	Come I Here World Hello
> 
>
> 


---



```c++
#include <iostream>
#include <string>
#include <stack>

using namespace std;
int main(){
	stack<string> a;
	string s;
    // 将各单词字符串作为整体，利用栈
	while (cin >> s) {
		a.push(s);
	}
	while (!a.empty()) {
		cout << a.top();
		a.pop();
		if (!a.empty()) {
			cout << " ";
		}
	}
    cout << "\n";
	return 0;
}


```

