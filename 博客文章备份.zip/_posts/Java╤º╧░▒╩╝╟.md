---
title: Java学习笔记
date: 2019-01-01 20:24:59
tags: Java
---

[toc]

<!--more-->

## Interface ##
接口内所有方法不可在接口实现

接口中的变量默认是常量,即 public static final

代码块执行顺序(Derived extends Base)：
Base static --> Derived static --> Base anonyous -->
Base constructor --> Derived anonyous --> Derived constructor

## cast转型 ##
以下代码可行(Man extends Human)：

```java
Human obj1 = new Man();
Man obj2 = (Man)obj1;
```

## 静态方法使用静态变量或方法内的临时变量 ##

## final ##
final修饰的变量不可修改其值

final修饰的对象实例不可修改其指向,可修改对象内部的值

final修饰的类不可被继承

//java中将const作为关键字保留,但没有功能

## 常量池 ##

常量式(字面量)赋值创建,位于栈,将被常量化

new对象进行创建,位于堆,不会常量化


Boolen :true,false

Byte: 0-127

Character :0-127

Short:-128-127

Integer:-128-127

Long:-128-127

Float,Double 无常量池

常量池编译器自动优化 

```java
String s0 = "abcdef";
String s1 = "a"+"b"+"c";
String s2 = "abc";
String s3 = new String("abc");
String s4 = new String("abc");
String s5 = s1 + "def";    //表达式涉及到变量，故编译器不优化
String s6 = "abc" + "def"; //都是常量，编译器会自动优化成abcdef
String s7 = "abc" + new String ("def");//涉及到new对象，编译器不优化
String s8 = s3 + "def";//涉及到new对象，编译器不优化
//s1 == s2, s0 == s6
```

## 包装类 ##

基本类型赋值给包装类对象，自动装箱

基本类型和包装类进行比较，包装类自动拆箱

包装类运算自动拆箱为基本类型并运算

```java
int i1 = 10;
Integer i2 = 10;                // 自动装箱
System.out.println(i1 == i2);   //true

Integer i3 = new Integer(10);
System.out.println(i1 == i3);  //true

System.out.println(i2 == i3); //false
	
Integer i4 = new Integer(5);
Integer i5 = new Integer(5);
System.out.println(i1 == (i4+i5));   //true
System.out.println(i2 == (i4+i5));   //true
System.out.println(i3 == (i4+i5));   //true
```


## BigInteger大数类 ##
```java
bi1.add(bi2));
bi1.subtract(bi2));
bi1.multiply(bi2));
bi1.divide(bi2));
bi1.remainder(bi2));
bi1.min(bi2));
bi1.max(bi2));
bi1.equals(bi2));
BigInteger []divideAndReminder = bi1.divideAndRemainder(bi2);
```

## 生成随机数三种方法 ##

```java
//生成0-10的随机数	
Math.random()*9+1;
```

 	//用Random类生成随机数
    Random rd = new Random();
    System.out.println(rd.nextBoolean());
	System.out.println(rd.nextInt());
	System.out.println(rd.nextLong());
	System.out.println(rd.nextInt(10)); // 0--10的随机数
	System.out.println(rd.nextDouble());

```java
//jdk8.0新增方法
rd.ints(); //生成无限个int随机数
int[] arr = rd.ints(10).toArray(); //取10个随机数组成数组
```

## String类常用方法 ##
String方法都只是返回一个修改后的新串,而不改变原字符串

charAt(int);indexOf(char);concat(String);contains(String);endsWith(String);
equals(String);equalsIgnoreCase(String)

trim();//返回去除前后空格的新字符串

split(char c);//返回以c为分隔符的字符串数组

substring(int begin,int end);//返回从begin到end的新串,此处的substring均小写

replace();replaceAll();二者都是返回全部替换的新串，但是replaceAll支持正则表达式

## StringBuffer ##

字符串拼接速度StringBuilder > StringBuffer >>> String

StringBuffer原地修改,可变对象

StringBuffer的的初始大小为（16+初始字符串长度）即capacity=16+初始字符串长度

length:实际长度  capacity:存储空间大小

一旦length大于capacity时，capacity便在前一次的基础上加1后翻倍

如果append的对象很长，超过(加1再2倍数额)，将以最新的长度更换

## DecimalFormat数字格式 ##

Decimal实例对象的构造函数传入格式规则字符串

调用DecimalFormat实例对象的format方法返回格式要求的字符串

“#”代表尽可能省去0，“0”表示不可省去

```java
new DecimalFormat("#.00").format(0.654);  			//返回".65"
new DecimalFormat("0.00").format(0.654);  			//返回"0.65"
new DecimalFormat(",000.00").format(123456789.401);	//返回"123,456,789.40"
new DecimalFormat(",000.##").format(123456789.401);	//返回"123,456,789.4"
```

## MessageFormat文本格式 ##

		String pattern的格式：
		 { ArgumentIndex , FormatType , FormatStyle }
	     -- ArgumentIndex
		 -- FormatType:
	             number
	             date
	             time
	             choice（需要使用ChoiceFormat）
	     -- FormatStyle:
	             short
	             medium
	             long
	             full
	             integer
	             currency
	             percent
	             SubformatPattern

通过	调用MessageFormat类的静态方法实现

MessageFormat.format(String pattern,Object[] args)	//返回格式化后的字符串

	eg:
	MessageFormat.format("Oh,{0,number,,###.##} is a {1} good!!",new Object{6456456.135465,"good"});			//返回"Oh,6,456,456.14 is a good number!!"

## ArratList<>和LinkedList<>及Vector<> ##

泛型使用包装类

add();remove();size();

List可用addFirst()之类的方法

Vector和ArrayList类似，非同步情况下用ArrayList

## HashSet<> 和TreeSet<>及LinkedHashSet<>##

### HashSet ###

HashSet装的是HashMap,其不重复且无顺序可言,可容纳null

size();contains(Element);

clear()		//清除集合内元素

retainAll(hs)	//取交集	

	判断重复的方法：
		1.先判断int HashCode()返回值是否相同
		2.再判断boolean equals(obj2)返回值是否为true

hashCode(),equals()和toString()方法三位一体,最好同时修改

---

### LinkedHashSet保留顺序 ###

---

### TreeSet ###

<p></p>
不可容纳null

	判断重复的方法：
		1.判断数据类的int compareTo()返回值与0比较


	自定义排序方法：
		无参构造函数默认CompareTo自然排序
		自定义Comparator对象作为构造参数传入

自定义Comparator重写int compare(ElemType a,ElemType b)方法

## HashMapM<K,V>和Hashtable<K,V> ##

### HashMap ###

<p></p>
K-V对允许为null

1K对应1V

---
### Hashtable ###

<p></p>
多线程同步

K-V对不允许为null

contains();等价于containsValue();

containsKey();get();

clear();清除元素

---
### LinkedHashMap ###

<p></p>
保留顺序,允许有null

## Properties以文件形式读取K-V对 ##

Properties继承于Hashtable

将K-V对保存在文件中

load(InputStream)加载流中原有的K-V对

store(OutputStream,String)写入所有K-V对到流

getProperty()获取K对应的V

setProperty()插入一个K-V对


## TreeMap<K,V> ##

基于红黑树

K不可为null

按照Key大小或compareTo()方法排序

## Arrays工具类 ##
--sort()

--binarySearch()	//二分法检索

--copyOf()

--fill()
  fill(int[],fromIndex,toIndex+1,value)

--equals()

## ArrayList<E> ##

与Arrays大致类似,处理List

## File类 ##

--exists()

--mkdir()创造单级目录,mkdirs()

--isDirectory()

--isFile()

--creatNewFile() throws IOException

--delete()

--getName()

--getPath(),getParent()返回上级目录

--File[] listFiles() 返回当前目录文件的数组,不递归列出子目录文件

---

### Path类(jdk7.0++) ###

可由File类对象的toPath()转化	</br>
eg:							</br>	
File a = new File("D:/a.txt");
Path pa = a.toPath();

可用Paths工具类的get("FilePath")方法返回Path的实例对象 </br>
Paths.get("FilePath");

--resolve() 可以理解成cd指令

## BufferReader && BufferWriter ##

### BufferReader: ###
<p></p>
new BufferReader(new InputStreamReader(new FileInputStream(File or String)))	

--readLine()

--close()

### BufferWriter ###
<p></p>

new BufferWriter(new OutputStreamWriter(new FileOutputStream(String or File),StandardCharsets.UTF_8))

--write()

--newLine()

--close()

## try-source(jdk7++) ##

try结束后自动关闭资源

```java
try(Coding here){

 }
```

## properties文件 ##

### 文件命名格式 ###

baseName_language_country.properties

### 文件内容 ###

Key = Value

---
### Charset类 ###
<p></p>
Charset.defaultCharset()

--name()

---

### Locale类 ###
<p></p>
Locale(language,country)

Locale.getDefault()

Locale.getAvailableLocales()

---

### ResourceBundles类 ###
<p></p>
根据Locale要求加载对应的properties文件

Resource.getBundle("baseName",Locale)

--getString("Key")

-----properties文件匹配优先顺序中,自定义传入的Locale参数优先级最高,国家优先级高于语言

-----eg:

```java
Locale myLocale = new Locale("en","US");
ResourceBundle myBundle = ResourceBundle.getBundle("msg",myLocale);
//会依次匹配以下文件
//msg_en_US.properties
//msg_en.properties
//msg_zh_CN.properties	/*默认的Loacle*/
//msg_zh.properties
//msg.properties

## RegExp正则表达式 ##
```

### Pattern类 ###

--compile(reg)返回一个将正则表达式字符串编译成的Pattern对象

--matcher(input)返回一个Matcher类的对象

### Matcher类 ###

--start()返回index

--end()返回index

--boolean lookingAt()部分匹配

--boolean matches()完全匹配

**appendReplacement和appendTail:**

--appendReplacement(StringBuffer,replacement)

--appendTail(StringBuffer)

(1)替换所有replaceAll()

```java
while(matcher.find()){
	matcher.appendReplacement(sb,replacement);	
}
matcher.appendTail(sb);	
```

(2)替换第一个

```java
if(matcher.find()){
	matcher.appendReplacement(sb,replacement);
}	
```
  	matcher.appendTail(sb);

## DomReader ##

```java
DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
DocumentBuilder db = dbf.newDocumentBuilder();
Document d = (Document) db.parse("file.xml");
```


## Exception ##

子类重写父类方法时，不可抛出比父类多的异常或不在父类抛出的异常的下继承链的异常，
因为继承必须满足里氏代换原则，即子类必须可以在任何场合替换父类

自定义异常类继承Exception,则默认为编译期异常

## 多线程 ##
#### 尽量使用Runnable接口创建多线程程序，降低耦合性，增强扩展性 ####
### Thread类实现 ###

<p></p>
创建的Thread子类重写run()方法

通过调用子类对象的start()方法，开辟新的栈空间并将run()中的代码压栈执行

Thread.sleep()，使当前的进程暂停指定的毫秒


### Runnable接口实现 ###
<p></p>
实现类中重写Runnable的run()方法

创建Thread类对象，向其构造方法传入实现类对象，通过调用该Thread类对象的start()开启

## 线程安全问题 ##

### 同步代码块： ###

	synchronized(obj){
	
	  可能出现线程安全问题的代码
	
	}

### 同步方法 ###
</p>

在方法前加修饰关键字synchronized

锁对象默认是实现类对象,也就是this

（静态方法的锁对象是本类的class属性）

### Lock接口 (jdk1.5+) ###
</p>
在成员位置创建一个ReentranLock对象
	
在可能出问题的代码前调用对象的lock()方法获取锁，在代码后调用unlock()释放锁

## 线程状态 ##
![在这里插入图片描述](https://s2.loli.net/2022/01/15/PpbkrqwomleKFCj.png)
### wait()&notify() ###
<p>
调用wait()或者notify()之前，必须使用synchronized语义绑定住被wait/notify的对象。

wait(long timeout),在waiting状态的最大时间限度,逾时自动唤醒

notify()唤醒随机的一个等待线程

notifyAll()全唤醒

## Lambda表达式 ##

要求使用的接口有且只有一个抽象方法

可简化匿名内部类的书写

**格式:(参数列表)->{重写的代码}**

**可推导即可省略：**

&nbsp;&nbsp;1.参数类型可省略

&nbsp;&nbsp;2.参数只有一个时,小括号可省略

&nbsp;&nbsp;3.大括号只有一句代码语句时,{}和return和;可同时省略	
 	