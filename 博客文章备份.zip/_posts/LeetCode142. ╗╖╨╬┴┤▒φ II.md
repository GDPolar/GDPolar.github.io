---
title: LeetCode142. 环形链表 II
date: 2022-01-03 20:24:59
tags: 
	- 数据结构与算法
	- LeetCode
---


#### [142. 环形链表 II](https://leetcode-cn.com/problems/linked-list-cycle-ii/)<!--more-->



> 给定一个链表，返回链表开始入环的第一个节点。 如果链表无环，则返回 null。
>
> 不允许修改 链表。
>
> 示例 1：
>
> 	输入：head = [3,2,0,-4], pos = 1
> 	输出：返回索引为 1 的链表节点
> 	解释：链表中有一个环，其尾部连接到第二个节点。
>
> 示例 2：
>
> 	输入：head = [1,2], pos = 0
> 	输出：返回索引为 0 的链表节点
> 	解释：链表中有一个环，其尾部连接到第一个节点。
>
> 示例 3：
>
> 	输入：head = [1], pos = -1
> 	输出：返回 null
> 	解释：链表中没有环。
>
>
> 提示：
>
> 
> 	链表中节点的数目范围在范围 [0, 104] 内
> 	-105 <= Node.val <= 105
> 	pos 的值为 -1 或者链表中的一个有效索引
> 

---

## 此题主要是数学运算

​	快慢指针法，快指针每次移动两个节点，慢指针每次移动一个节点，有环的话，一定会在环内相遇。

​	因为快指针走两步，慢指针走一步，相对来说，快指针是一个节点一个节点的靠近慢指针的，所以一定会重合。

​	假设从头结点到环形入口节点的节点数为x，环形入口节点到 快指针与慢指针相遇节点节点数为y，从相遇节点再到环形入口节点节点数为 z。

![image-20220127215744568](https://s2.loli.net/2022/01/27/FhRKAkME6PGtNgj.png)

```
(x + y) * 2 = x + y + n (y + z)
x = (n - 1) (y + z) + z
```
​	当n为1的时候，公式就化为 x = z，即**从头结点出发一个指针，从相遇节点也出发一个指针，这两个指针每次只走一个节点，那么当这两个指针相遇的时候就是环形入口的节点**。


```c++
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    ListNode *detectCycle(ListNode *head) {
         if (head == NULL || head->next == NULL) {
            return NULL;
        }
        ListNode *fast = head, *slow = head, *meeting = NULL;
        while(fast != NULL && fast->next != NULL) {
            slow = slow->next;
            fast = fast->next->next;
            // 找到相遇处
            if (fast == slow) {
                meeting = fast;
                break;
            }
        }
        return NULL;
        // 从头结点出发一个指针，从相遇节点也出发一个指针，每次都只走一步， 两指针相遇处就是环形入口的节点
        } else {
            ListNode *res = head;
            while (res != meeting) {
                res = res->next;
                meeting = meeting->next;
            }
            return res;
        }
    }
};
```