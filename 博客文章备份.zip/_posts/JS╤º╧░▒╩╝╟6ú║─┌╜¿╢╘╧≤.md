---
title: JS学习笔记6：内建对象
date: 2019-04-28 20:24:59
tags: JS学习
---

JS的常用对象包括Array、Date、Math、String等 <!--more-->
- 数组Array中可以放任何类型的数据

```javascript
let arr  = new Array();
arr[2] = 1;
console.log(arr); // Array(3) [ <2 empty slots>, 1 ]
console.log(arr[1]); // undefined
console.log(arr[3]); // undefined

let aa = [0, "hello", null, undefined, {name: "San"}, function() {alert("1")}];	
console.log(a); // Array(6) [ 0, "hello", null, undefined, {…}, aa() ]

```

- push()在末尾添加一个或多个元素并返回新的长度

  pop()删除并返回最后一个元素

  unshift()在开头添加一个或多个元素并返回新的长度

  shift()删除并返回第一个元素

```javascript
let arr = new Array(); // 2

arr.push(123, "hel");	// 2
console.log(arr.pop()); // hel
console.log(arr); // Array [ 123 ]

arr.unshift(666); // 2
console.log(arr.shift()); // 666
console.log(arr); // Array [ 123 ]
```

- 数组的forEach()方法，需要传入一个函数对象，浏览器将各个元素的currentValue, index, arr作为实参传入函数并执行

  IE8及以下不支持
```javascript
let arr = ["hello", true];
arr.forEach(function(currentValue, index, arr) {
    console.log(currentValue, index, arr);	// 其中arr就是当前的数组
});
/* 
 * hello 0 Array [ "hello", true ]
 * true 1 Array [ "hello", true ]
 */
```

- slice(start, end)从某个已有的数组返回选定的元素，闭区间，end参数可选，支持负数
```javascript
let arr = ["hello", true, null, 32];
console.log(arr.slice(0,2)); // Array [ "hello", true ]
console.log(arr.slice(2)); // Array [ null, 32 ]
console.log(arr.slice(-3)); // Array(3) [ true, null, 32 ]
```

- splice(start,howmany,item1.....)删除原数组中指定数量的元素，添加新元素，并将删除的元素作为新数组返回
```javascript
let arr = ["hello", true, null, 32, new Person()];
arr.splice(2,3,"item1",666); // Array(3) [ null, 32, {} ]
console.log(arr); // Array(4) [ "hello", true, "item1", 666 ]
```

- concat()连接多个数组作为新数组返回，不会改变现有的数组
```javascript
let arr1 = ["hello"], arr2 = [12];
console.log(arr1.concat(arr2)); // Array [ "hello", 12 ] 
console.log(arr1); // Array [ "hello" ]
```
- join()将数组的所有元素放入一个字符串，并用指定的分隔符进行分割（默认为逗号）

```javascript
let arr = [12, "hello"];
console.log(arr.join()); // 12,hello
console.log(arr.join(" and ")); // 12 and hello
```

- reverse()翻转原数组

```javascript
let arr = [12, "hello"];
arr.reverse(); 
console.log(arr); // Array [ "hello", 12 ]
```

- sort()对原数组进行排序，可传入一个比较函数。需要升序排列则返回a-b

```javascript
let arr = [40, 100, 1, 5, 25, 10];
arr.sort(function(a, b) {return a-b});
console.log(arr); // Array(6) [ 1, 5, 10, 25, 40, 100 ]
```

---

- 直接使用构造函数创建一个Date对象，则会封装当前代码执行时间
```javascript
let d1 = new Date();
let d2 = new Date("12/05/2018 11:22:33");
console.log(d2); // Date Wed Dec 05 2018 11:22:33 GMT+0800 (中国标准时间)
```

[Date对象提供了许多方法获取日期、星期等]: https://www.w3school.com.cn/jsref/jsref_obj_date.asp



---

Math作为对象使用调用其属性和方法

```javascript
Math.ceil() ,  Math.floor() 向上取整和向下取整
    console.log(Math.ceil(12.03));//13
    console.log(Math.ceil(12.92));//13
    console.log(Math.floor(12.3));//12
    console.log(Math.floor(12.9));//12

Math.round() 四舍五入
    Math.round(-16.3) = -16
    Math.round(-16.5) = -16
    Math.round(-16.51) = -17

Math.random() 取[0,1)的随机小数
	
Math.max() and Max.min() 获取一组数据中的最大值和最小值
    console.log(Math.max(10,1,9,100,200,45,78));
    console.log(Math.min(10,1,9,100,200,45,78));

Math.pow()获取一个值的多少次幂 , Math.sqrt()对数值开方
    Math.pow(10，2) = 100;
    Math.sqrt(100) = 10;
```

---

- 字符串是以字符数组保存的

  字符串的大多数方法不改变原字符串

```javascript
charAt(index) 返回字符串中指定index位置的字符。
let str = "abc123def666";
console.log(str.charAt(6)); // d

indexOf(searchvalue, fromindex可选) 返回 指定值searchvalue 在字符串对象中首次出现的位置。
从 fromIndex 位置开始查找，如果不存在，则返回 -1。
console.log(str.indexOf("123"));    // 3
console.log(str.indexOf("123", 2)); // 3

search(regexp) 检索与正则表达式相匹配的值。
console.log(str.search("1")); // 3
console.log(str.search(/[0-9]/)); // 3

replace(regexp/substr,replacement) 在字符串中用一些字符替换另一些字符，或替换一个与正则表达式匹配的子串
被用来在正则表达式和字符串直接比较，然后用新的子串来替换被匹配的子串。
console.log(str.replace("1", "-one-"));
console.log(str.replace(/\d/, "-one-"));

match(searchvalue/regexp) 返回符合匹配结果的数组
console.log(str.match(/\d+/)); // ["123", index: 3, input: "abc123def666"]


split(separator) 将字符串按separator为分隔符分割成一个字符串数组
console.log(str.split("1")); // ["abc", "23def666"]

slice(start,end) 获取一个新的指定字符串，[start, end)，参数可以为负数
substring(start,end) 与slice类似，但不接受负的参数
console.log(str.slice(1, 4)); // bc1

substr(start,length可选) 抽取从 start 下标开始的长度为length的字符
console.log(str.substr(3, 3)); // 123

toLowerCase() 将调用该方法的字符串值转为小写形式，并返回。
toUpperCase() 将字符串转换成大写并返回。
console.log(str.toLowerCase()); // abc123def666
console.log(str.toUpperCase()); // ABC123DEF666
```