---
title: 1004 成绩排名
date: 2022-03-31 20:24:59
tags: 
	- 数据结构与算法
	- PAT
---


#### [1004 成绩排名](https://pintia.cn/problem-sets/994805260223102976/problems/994805321640296448)<!--more-->



> 读入 n（>0）名学生的姓名、学号、成绩，分别输出成绩最高和成绩最低学生的姓名和学号。
>
> ## 输入格式：
>
> 每个测试输入包含 1 个测试用例，格式为
>
> ```
> 第 1 行：正整数 n
> 第 2 行：第 1 个学生的姓名 学号 成绩
> 第 3 行：第 2 个学生的姓名 学号 成绩
>   ... ... ...
> 第 n+1 行：第 n 个学生的姓名 学号 成绩
> ```
>
> 其中`姓名`和`学号`均为不超过 10 个字符的字符串，成绩为 0 到 100 之间的一个整数，这里保证在一组测试用例中没有两个学生的成绩是相同的。
>
> ## 输出格式：
>
> 对每个测试用例输出 2 行，第 1 行是成绩最高学生的姓名和学号，第 2 行是成绩最低学生的姓名和学号，字符串间有 1 空格。
>
> ## 输入样例：
>
> 	3
> 	Joe Math990112 89
> 	Mike CS991301 100
> 	Mary EE990830 95
> 
>
> ## 输出样例：
>
> 	Mike CS991301
> 	Joe Math990112
> 
>


---

## 此题目主要是练习结构体的定义及输入输出

```c++
#include <iostream>
#include <string>

using namespace std;
int main() {
    struct info {
        string name;
        string num;
        int score;
    };
    int n;
    int i;
    cin >> n;
    struct info stu[n];
    for (i = 0; i < n; i++) {
        cin >> stu[i].name >> stu[i].num >> stu[i].score ;
    }
    int max = 0, min= 0;
    for (i = 0; i < n; i++) {
        max = stu[i].score > stu[max].score ? i : max; 
        min = stu[i].score < stu[min].score ? i : min; 
    }
    cout << stu[max].name << " " << stu[max].num << '\n' << stu[min].name << " " << stu[min].num << '\n';
    return 0;
}
```