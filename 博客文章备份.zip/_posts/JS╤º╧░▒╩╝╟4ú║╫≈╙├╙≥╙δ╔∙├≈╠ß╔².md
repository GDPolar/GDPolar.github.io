---
title: JS学习笔记4：作用域与声明提升
date: 2019-04-26 20:24:59
tags: JS学习
---

- 全局作用域中有一个全局对象window，代表一个浏览器的窗口，由浏览器创建。在全局作用域中声明变量实际是为window对象添加属性。因此可把全局作用域理解为特殊的最大的函数作用域。<!--more-->
```javascript
console.log(a);	// 由于a未定义，报错
console.log(window.a);	// undefined
let a = 1;
console.log(window.a);	// 1
```

- var关键字定义的函数及变量的声明都将被提升到函数的最顶部，而使用函数声明形式创建的函数会在所有代码执行之前被创建。 
```javascript
f1(); // x= 5,f= function (){}
console.log("x= " + x); // x= undefined
console.log("f= " + f); // f= undefined
x = 5; 
f = function (){};
console.log("x= " + x); // x= 5
console.log("f= " + f); // f= function (){}
var x, f; 
function f1() {	// 在所有代码执行之前被创建
    console.log("x= " + x + ",f= " + f);
};

f2(); // undefined
function f2() {
    console.log(a);
    var a = 2;
}
```

- 函数内使用未声明的变量即为上一层的的变量

```javascript
var a = 1;
f3(); // 1
function f3() {
    console.log(a);	// 此时的a为f3()函数体的上一级，即为window.a
    a = 3;	// 此处的a未使用var关键字，视为普通的赋值，又因为f3()中未定义a，所以此时的a为上一层的a，即window.a，修改的是全局的a
};
console.log(a); // 3
```

- 在每次函数调用时都会将this作为一个隐含的参数传入，this指向函数执行的上下文对象

```javascript
var name = "Lisi";
function fun1() {
    console.log(name);	// 此处相当于window.name
}
function fun2() {
    console.log(this.name);	
}
fun1();	// "Lisi"
fun2(); // "Lisi"
let obj1 = {
    name : "San",
    sayName1 : fun1,
    sayName2 : fun2
};
obj1.sayName1(); // "Lisi"
obj1.sayName2(); // "San"
```

