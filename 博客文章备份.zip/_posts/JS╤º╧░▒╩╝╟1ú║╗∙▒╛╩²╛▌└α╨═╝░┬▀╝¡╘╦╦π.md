---
title: JS学习笔记1：基本数据类型及逻辑运算
date: 2019-04-23 20:24:59
tags: JS学习
---

JS基本数据类型<!--more-->



```html
<script type="text/javascript" src="js/scrpit.js">
        //script标签用src属性引入外部js文件后，标签内部的js代码会被忽略
    	alert("此处不会弹窗")
</script>
```



- 标识符只允许数字、字母、下划线和$，且不允许以数字开头

```javascript
let a_1_$ = 123;
```



- 5种基本数据类型String、Number(整数和浮点数)、Boolean(true和false)、Null(null)、Undefined(undefined) 和1种引用数据类型Object

- typeof运算符的返回类型为字符串，值包括 'undefined' 、'boolean'、'string'、 'number'、'object'   和'function'

```javascript
console.log(typeof NaN); // "number"
console.log(typeof new Array()); // "object"
console.log(typeof null);// 由于历史原因，null类型进行typeof操作符后，结果是"object"
console.log(typeof typeof null); // "string"
```





- String()转换为String类型

```javascript
let a = 213;
String(a);  // 此时String(a)等价于a.toString()，底层调用是一样的

a = null;
String(a);  // 无 a.toString() 方法
```



- Number()转化为Number类型

```javascript
a = "0.123";
console.log(Number(a)); //转化为相应的number类型数据

let b = "";
console.log(Number(b)); //空串 --> 0

let c = "123k";
console.log(Number(c)); //NaN

let d = true;
console.log(Number(d)); //true --> 1

let e = null;
console.log(Number(e)); //null --> 0

let f = undefined;
console.log(Number(f)); //undefined --> NaN
```



- parseInt(string: string, radix?: number)

```javascript
a = "010";
console.log(parseInt(a,8)); // 指定进制radix转化为number
```



- Boolean()转化为Boolean类型

```javascript
console.log(Booleanl(a)); // 除了 0、NaN、null、空串"" 外，其余的Boolean()都返回true
```



- 任何值与字符串相加，都返回字符串。其他的加法、减法、乘除法都转化number，再进行运算

```javascript
console.log(NaN + "1"); // "NaN1"

console.log(3 + null);  // 3
console.log(3 + undefined);  // NaN
console.log(100 - "1"); // 99
console.log(3 * null);  // 0 

```

<!--more-->

逻辑运算

- 根据“短路原则”。

  两值相与时，第一个值为true，则返回第二个值；第一个值为false，则返回第一个值。

  两值相或时，第一个值为true，则返回第一个值；第一个值为false，则返回第二个值。

```javascript
console.log(3 && 5);	// 5
console.log(NaN && 0);	// NaN

console.log(3 || 5);	// 3
console.log("" || 0);	// 0
```

- 比较运算时，自动转化为number类型。任何值与NaN进行比较运算，都返回fasle

```javascript
console.log(1 > "");	// 等价于1 > 0，返回true
console.log(null <= "hello"); // 等价于 0 <= NaN，返回false
```

​	特别地，当两字符串相比较时，即比较Unicode码

```javascript
console.log("2.a" > "2.b");	// false，因为a为97，b为98
console.log("1a" > "10asd");// true，因为a为97，0为48
```

- 进行 == 比较运算时

  （1）如果两个值类型相同，再进行三个等号(===)的比较

  （2）如果两个值类型不同，也有可能相等，需根据以下规则进行类型转换在比较：

  ​        1）如果一个是null，一个是undefined，那么相等

  ​        2）如果一个是字符串，一个是数值，把字符串转换成数值之后再进行比较

  ```javascript
console.log(1 == "1");	// true
console.log(1 == "1a");	// false，等价于1 == NaN
console.log(null == undefined); // true
  ```

​	特别地，NaN不与任何值相同（包括它自己），用isNaN()来判断

