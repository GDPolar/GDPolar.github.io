---
title: LeetCode59. 螺旋矩阵 II
date: 2022-01-01 20:24:59
tags: 
	- 数据结构与算法
	- LeetCode
---

#### [59. 螺旋矩阵 II](https://leetcode-cn.com/problems/spiral-matrix-ii/)<!--more-->



> 给你一个正整数 n ，生成一个包含 1 到 n2 所有元素，且元素按顺时针顺序螺旋排列的 n x n 正方形矩阵 matrix 。
>
>  ![img](https://s2.loli.net/2022/01/21/JaXpcMAvOHZ4bKh.jpg)
>
> 示例 1：
>
> 	输入：n = 3
> 	输出：[[1,2,3],[8,9,4],[7,6,5]]
> 
> 示例 2：
> 
>	输入：n = 1
> 	输出：[[1]]
> 
>
> 提示：
>
> 	1 <= n <= 20

---

## 求解本题要坚持“**循环不变量原则**”

模拟顺时针画矩阵的过程

发现边界条件非常多，一圈下来，要画每四条边，这四条边怎么画，每画一条边都要坚持一致的左闭右开，或者左开又闭的原则，这样这一圈才能按照统一的规则画下来。

![螺旋矩阵](https://s2.loli.net/2022/01/21/bvX5rdy8FYVuRWx.png)

这里每一种颜色，代表一条边，可以看出每一个拐角处的处理规则，拐角处让给新的一条边来继续画。

这是坚持了每条边左闭右开的原则。

```c++
class Solution {
public:
    vector<vector<int>> generateMatrix(int n) {
        // 注意构造二维vector的格式
        vector<vector<int>> res(n, vector<int>(n,0));
        // 一次循环构造四条边
        int loop = n / 2; // 圈数
        if (n % 2 == 1) { // n为奇数时，单独给最中间位置赋值
            res[n / 2][n / 2] = n * n; 
        }
        int num = 1;
        int startX = 0, startY = 0;	// 每一圈的起点，位于相对左上角
        int i, j;
        int k = n - 1; // 每条边的长度
        while (loop-- > 0) {
            i = startX;
            j = startY;
            // 注意各个边界
            while (j < startY + k) {
                res[i][j] = num++;
                j++;
            }
            while (i < startX + k) {
                res[i][j] = num++;
                i++;
            }
            while (j > startY) {
                res[i][j] = num++;
                j--;
            }
            while (i > startX) {
                res[i][j] = num++;
                i--;
            }
            k -= 2;	
            startX += 1; //进入下一圈，起点向右下方移动一格
            startY += 1;
        }
        return res;
    }
};
```

