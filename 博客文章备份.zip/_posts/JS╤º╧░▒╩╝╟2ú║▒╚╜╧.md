---
title: JS学习笔记2：比较
date: 2019-04-24 20:24:59
tags: JS学习
---


```javascript
null > 0   // null 尝试转型为number，则为0，所以结果为 false
null >= 0  // null 尝试转为number，则为0，结果为 true
null == 0  // null在设计上，在此处不尝试转型，所以结果为 false
```
<!--more-->

-  内部相等性运算算法

> 11.9.3 The Abstract Equality Comparison Algorithm 
> The comparison x == y, where x and y are values, produces true or false. Such a comparison is performed as follows: 
>
> 1. If Type(x) is different from Type(y), Go to step 14. 
> 2. If Type(x) is Undefined, return true. 
> 3. If Type(x) is Null, return true. 
> 4. If Type(x) is not Number, go to step 11. 
> 5. If x is NaN, return false. 
> 6. If y is NaN, return false. 
> 7. If x is the same number value as y, return true. 
> 8. If x is +0 and y is -0, return true. 
> 9. If x is -0 and y is +0, return true. 
> 10. Return false. 
> 11. If Type(x) is String, then return true if x and y are exactly the same sequence of characters (same length and same characters in corresponding positions). Otherwise, return false. 
> 12. If Type(x) is Boolean, return true if x and y are both true or both false. Otherwise, return false. 
> 13. Return true if x and y refer to the same object or if they refer to objects joined to each other (see 13.1.2). Otherwise, return false. 
> 14. If x is null and y is undefined, return true.  
> 15. If x is undefined and y is null, return true. 
> 16. If Type(x) is Number and Type(y) is String, return the result of the comparison x == ToNumber(y). 
> 17. If Type(x) is String and Type(y) is Number, return the result of the comparison ToNumber(x)== y. 
> 18. If Type(x) is Boolean, return the result of the comparison ToNumber(x)== y. 
> 19. If Type(y) is Boolean, return the result of the comparison x == ToNumber(y). 
> 20. If Type(x) is either String or Number and Type(y) is Object, return the result of the comparison x == ToPrimitive(y). 
> 21. If Type(x) is Object and Type(y) is either String or Number, return the result of the comparison ToPrimitive(x)== y. 
> 22. Return false.

---

- 内部关系运算算法

> 11.8.5 The Abstract Relational Comparison Algorithm 
> The comparison x < y, where x and y are values, produces true, false, or undefined (which indicates that at least one operand is NaN). Such a comparison is performed as follows: 
> 1. Call ToPrimitive(x, hint Number). 
> 2. Call ToPrimitive(y, hint Number). 
> 3. If Type(Result(1)) is String and Type(Result(2)) is String, go to step 16. (Note that this step differs from step 7 in the algorithm for the addition operator **+ *  in` `using *and instead of or.) 
> 4. Call ToNumber(Result(1)). 
> 5. Call ToNumber(Result(2)). 
> 6. If Result(4) is NaN, return undefined. 
> 7. If Result(5) is NaN, return undefined. 
> 8. If Result(4) and Result(5) are the same number value, return false. 
> 9. If Result(4) is +0 and Result(5) is -0, return false. 
> 10. If Result(4) is -0 and Result(5) is +0, return false. 
> 11. If Result(4) is +∞, return false. 
> 12. If Result(5) is +∞, return true. 
> 13. If Result(5) is -∞, return false. 
> 14. If Result(4) is -∞, return true. 
> 15. If the mathematical value of Result(4) is less than the mathematical value of Result(5) — note that these mathematical values are both finite and not both zero — return true. Otherwise, return false. 
> 16. If Result(2) is a prefix of Result(1), return false. (A string value p is a prefix of string value q if q can be the result of concatenating p and some other string*r*. Note that any string is a prefix of itself, because r may be the empty string.) 
> 17. If Result(1) is a prefix of Result(2), return true. 
> 18. Let k be the smallest nonnegative integer such that the character at position k within Result(1) is different from the character at position k within Result(2). (There must be such a k, for neither string is a prefix of the other.) 
> 19. Let m be the integer that is the code point value for the character at position k within Result(1). 
> 20. Let n be the integer that is the code point value for the character at position k within Result(2). 
> 21. If m < n, return true. Otherwise, return false.

-  “>” 运算符

> The Greater-than Operator ( > ) 
  > The production RelationalExpression : 
  > RelationalExpression > ShiftExpression is evaluated as follows: 
  > 1. Evaluate RelationalExpression. 
  > 2. Call GetValue(Result(1)). 
  > 3. Evaluate ShiftExpression. 
  > 4. Call GetValue(Result(3)). 
  > 5. Perform the comparison Result(4) < Result(2). 
  > 6. If Result(5) is undefined, return false. Otherwise, return Result(5).

- ”>=” 运算符

> The Greater-than-or-equal Operator ( >= ) 
> The production RelationalExpression : 
> RelationalExpression >= ShiftExpression is evaluated as follows: 
>
> 1. Evaluate RelationalExpression. 
> 2. Call GetValue(Result(1)). 
> 3. Evaluate ShiftExpression. 
> 4. Call GetValue(Result(3)). 
> 5. Perform the comparison Result(2) < Result(4). (see 11.8.5). 
> 6. If Result(5) is true or undefined, return false. Otherwise, return true.

-  “==” 运算符

> The Equals Operator ( == ) 
> The production EqualityExpression : 
> EqualityExpression == RelationalExpression is evaluated as 
> follows: 
> 1. Evaluate EqualityExpression. 
> 2. Call GetValue(Result(1)). 
> 3. Evaluate RelationalExpression. 
> 4. Call GetValue(Result(3)). 
> 5. Perform the comparison Result(4) == Result(2). (see 11.9.3). 
> 6. Return Result(5).

---

根据以上ES3的实现，得出以下结论：

1. 关系运算符 和 相等运算符 并不是一个类别的.
2. 关系运算符,在设计上,总是需要运算元尝试转为一个number . 而相等运算符在设计上,则没有这方面的考虑.
3. 最重要的一点, 不要把 拿 a > b , a == b 的结果 想当然的去和 a >= b 建立联系.  正确的符合最初设计思想的关系是 a > b 与 a >= b是一组 . a == b 和其他相等运算符才是一组. 比如 a === b , a != b, a !== b .

```javascript
null > 0   // null 尝试转型为number，则为0，所以结果为 false
null >= 0  // null 尝试转为number，则为0，结果为 true
null == 0  // null在设计上，在此处不尝试转型，所以结果为 false
```

ps:这设计真是令人无语