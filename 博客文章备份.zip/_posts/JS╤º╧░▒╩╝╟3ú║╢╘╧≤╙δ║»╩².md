---
title: JS学习笔记3：对象、函数与原型
date: 2019-04-25 20:24:59
tags: JS学习
---

- JS中的对象包括内建对象、宿主对象、自定义对象<!--more-->

  --- 内建对象：由ES标准中定义的对象，在任何的ES的实现中都可以使用。比如：Math String Number Boolean Function Object.

  --- 宿主对象：由JS的运行环境提供的对象,主要指由浏览器提供的对象。比如 BOM DOM

  --- 自定义对象：自己创建的对象。	

```javascript
let obj = new Object();
let a = "age";
obj.name = "Zhangsan"; // 直接用 对象名.属性名 添加或访问属性
obj[a] = 22; // 也可用 对象名["属性名"] 添加或访问属性
delete obj.name; // delete删除对象属性
// obj: Object { age: 22 }
```


- 对象的比较与其他语言相似，位于堆区

- 使用对象字面量，可在创建对象的同时指定对象中的属性。用 属性名:属性值 来赋值

```javascript
let obj1 = {
    name : "Lisi", 
    age : 19,
    mom : {
    	name : "Liwu",
    	age : 49
	},
    sayName: function() {
        console.log(this.name);
    }
};
```

---

- 函数也是对象。

```javascript
function f1() {	// 使用函数声明创建函数
    console.log("f1");
}
let f2 = function(var1) { // 使用函数表达式创建函数
    console.log(var1);
};
f1();
f2();
// 也可以使用 let f1 = new Function("console.log('hello');");  不常用，了解即可
```

- 调用函数函数时未传入的参数为undefined，函数的返回值默认为undefined
```javascript
function f1(a, b) {	
    return typeof a + " " + typeof b
};
f1(1); // "number undefined"
function f2() {};
function f3() {
    return;
} 
f2(); // undefined
f3(); // undefined
```

- 由于函数也是对象，因此也可以作为参数传入
```javascript
function f(o) {
    o();
};
f(function f1() {console.log("f1");});
```

- 立即执行函数
```javascript
(function() {
    alert("hello");
})();
```

- for...in 遍历对象的所有属性
```javascript
let obj1 = {
    name : "Lisi", 
    age : 19,
    mom : {
    	name : "Liwu",
    	age : 49
	},
    sayName: function() {
        console.log(this.name);
    }
};
for (let i in obj1) {
    console.log(i + ":" +  obj1[i]);
};
/*
 * 输出如下：
 * name:Lisi
 * age:19 
 * mom:[object Object]
 * sayName:function() {
 *      console.log(this.name);
 *   }
*/
```

---

- 构造函数用new调用

  1）立即在堆中创建一个新的对象

  2）将新建的对象设为函数中的this

  3）逐行执行构造函数的代码

  4）返回所建对象

```javascript
function Person(name) {
    this.name = name;
}
console.log(Person());	// undefined
console.log(new Person("san")); // Object { name: "san" }
```

- 关键字instanceof可检查一个对象是否是某个类的实例

  任何对象都是Object的实例
```javascript
let p1 = new Person();
console.log(p1 instanceof Person); // true
console.log(p1 instanceof Object); // true
```

- 创建的每一个函数，都会自动添加一个属性prototype，该属性值为一个对象，即原型对象

  当函数作为构造函数调用时，其创建的对象都会有一个隐含属性指向构造函数的原型对象
  

```javascript
let p1 = new Person();
console.log(p1.__proto__ == Person.prototype); // true
```

- 访问一个对象的某属性或方法时，先在对象本身中寻找，若未找到，则沿着原型链向上找
```javascript
function Person(age) {
    this.age = age; 
};
Person.prototype.a = 123;
Person.prototype.sayName = function() {
    console.log(this.age);	
}
let p1 = new Person(16);
let p2 = new Person(18);
console.log(p1.a);	// 123
console.log(p2.__proto__); // Object { a: 123, … }
console.log(p2.sayAge()); // 18
```


- in运算符：依原型链检查是否含有指定属性

  对象的hasOwnProperty()检查对象自身是否含有指定属性

```javascript
obj.__proto__.a = 2;
console.log("a" in obj); // true
console.log(obj.hasOwnProperty("a")); // false
```

- 调用函数时，浏览器每次都会传入两个隐藏的参数：this与arguments（封装实参的对象）
```javascript
function fun() {
    console.log(arguments); // Arguments { 0: 12, 1: "aa", … }
    console.log(arguments[arguments.length - 1]); // aa
    console.log(arguments.callee == fun); // true
}
```